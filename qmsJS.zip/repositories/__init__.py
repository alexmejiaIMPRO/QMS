"""
Repository package initialization
"""
from .base_repository import Repository

__all__ = ["Repository"]
