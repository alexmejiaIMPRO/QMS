"""
General Information app module
"""
from .routes import router

__all__ = ["router"]
