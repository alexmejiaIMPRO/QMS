"""
DMT (Defective Material Tag) app module
"""
from .routes import router

__all__ = ["router"]
